# 💡 Smart Light Control using ESP32 and Blynk

**Project by Savitha (Internship Task 1 – Smart Light Control)**

## 🧠 Objective
To design a smart light control system using ESP32 and the Blynk mobile app.

## 🧰 Components
- ESP32
- LED
- 220 Ω Resistor
- Blynk App
- Wi-Fi Connection (Wokwi-GUEST)

## ⚙️ Circuit Connection
- LED positive → GPIO 2  
- LED negative → GND (via 220 Ω resistor)

## 📲 Working
The ESP32 connects to the Blynk IoT app using Wi-Fi.  
A button widget (V0) in the app controls the LED — ON or OFF.

## 🖼 Output

**LED ON State**  
![LED ON](led_on.jpg)

**LED OFF State**  
![LED OFF](led_off.jpg)

## ✅ Result
The LED successfully responds to commands from the Blynk mobile app.
